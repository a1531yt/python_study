# サンプルコード

これは「Pythonクローリング＆スクレイピング -データ収集・解析のための実践開発ガイド-」のサンプルコードです。

http://gihyo.jp/book/2017/978-4-7741-8367-1


ディレクトリ名は節番号を表します。
例: ディレクトリ2-3には2.3節のサンプルコードが含まれています。

## 動作環境

Python 3.4および3.5で動作確認を行っています。
ただし、7-4/crawl_with_aiohttp.py と 7-4/slow_jobs_async.py はPython 3.4では動作しません。
7.4節のコラム「Python 3.4でasyncioを使う」を参照して書き換えてください。


## 備考

5-4に含まれる拡張子.rqのファイルはSPARQLクエリです。
ファイルの先頭がリスト番号を表します。

例: 5.15-sparql_query_tokyo.rq はリスト5.15のクエリです。


6-2, 6-3, 6-7, 6-8にはScrapyのプロジェクト構造をそのまま含めています。


## サンプルコードのライセンス

サンプルコードはCC0で提供します（※ただし6-1の中身を除く）。

目的にかかわらず、許可を得ずに自由に利用していただけます。
ただし、著作者からの推奨があるかのような記述は避けてください。

Creative Commons — CC0 1.0 全世界
https://creativecommons.org/publicdomain/zero/1.0/deed.ja

※6-1の中身はScrapyのWebサイト（https://scrapy.org/）から引用して利用しているものであり、CC0の対象外です。


## データのライセンス

以下のデータは、ライセンスに従って同梱しています。

### 1-3/yakei_kobe.csv

神戸市提供のオープンデータ「夜景スポット一覧」を加工したもの。

コピーライト：City of Kobe
ライセンス：CC-BY

https://data.city.kobe.lg.jp/data/dataset/dataset-00000006


### 5-4/000232384.pdf

新幹線旅客輸送量の推移

作成者：鉄道局鉄道サービス政策室
ライセンス：CC-BY

http://www.data.go.jp/data/dataset/mlit_20140919_2423
